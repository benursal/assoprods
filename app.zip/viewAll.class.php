<?php
//view all records in a table

class viewAll
{
	
	

}
?>