<?php //dropdown menu html structure
;?>
<ul id="sddm">
    <li><a href="index.php">Home</a>
    </li>
    <li><a href="#" 
        onmouseover="mopen('m1')" 
        onmouseout="mclosetime()">Purchase Order</a>
        <div id="m1" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a href="po.php">Create PO</a>
        <a href="viewPOs.php">View All POs</a>
        <a href="searchPO.php">Search PO</a>
        </div>
    </li>
     <li><a href="#" 
        onmouseover="mopen('m2')" 
        onmouseout="mclosetime()">Quotation</a>
        <div id="m2" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a href="quotation.php">Create Quotation</a>
        <a href="viewQuotes.php">View All Quotations</a>
        <a href="searchQuotation.php">Search Quotation</a>
        </div>
    </li>
     <li><a href="viewSuppliers.php">Suppliers</a>
    </li>
     <li><a href="viewCustomers.php">Customers</a>
   </li>
</ul>
<div style="clear:both"></div>