<?php
header("Location: doc/examples.html");
exit();
?>