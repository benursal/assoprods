<?php
include('successPage.php');

$success = new successWebPage('tae');
echo $success->displayPage();
?>