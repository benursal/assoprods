<?php
/* Created By : Edward Benedict Ursal
 * Date : July 13, 2009
 * Filename : mainFormList.class.php
 * Description : List the records from the mainform data.
 *
*/


?>