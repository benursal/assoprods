<?php
//purchase order 

class purchaseOrderList
{
	private $refNo; // reference number
	private $itemList;
	private $sumaTotal;


}
?>