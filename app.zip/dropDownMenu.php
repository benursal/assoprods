<?php
	//Javascript Drop Down Menu
	
	echo "
	<script language=\"javascript\" type=\"text/javascript\" src=\"js/dropDown.js\"></script>
	<link rel=\"stylesheet\" type=\"text/css\" href=\"styles/dropDown.css\">";

$menuList = include('dropDown.php');
 ?>
