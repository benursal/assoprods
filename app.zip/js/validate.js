// JavaScript Document
//validate entered values in Item Fields
function validate(num)
{
	var itm = document.getElementById('item'+num);
	var qty = document.getElementById('qty'+num);
	var unt = document.getElementById('unit'+num);
	var desc = document.getElementById('descript'+num);
	var up = document.getElementById('up'+num);
	var amount = document.getElementById('amount'+num); 
}