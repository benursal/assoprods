<?php

class successWebPage
{
	private $pageContent;

	public function successWebPage($content)
	{
		$this->pageContent = "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">
				<html>
				<head>
				<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">
				<title>SUCCESS!!!!</title>
				</head>
				
				<body>".$content."</body>
				</html>
		";
	}
	
	public function displayPage()
	{
		return $this->pageContent;
	}
}



?>